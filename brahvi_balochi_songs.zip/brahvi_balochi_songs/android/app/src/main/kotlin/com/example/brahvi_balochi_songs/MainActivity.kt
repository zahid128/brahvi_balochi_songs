package com.example.brahvi_balochi_songs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
