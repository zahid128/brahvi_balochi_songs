import 'dart:convert';
import '/Model/model_class.dart';
import 'package:http/http.dart' as http;



/*

Future<List<SongModel>> fetchSongs() async {
  final response = await http.get(Uri.parse('https://mocki.io/v1/0bfb4c1e-a836-48f5-9426-bcc24268482b'));
  if (response.statusCode == 200) {
    List<dynamic> data = jsonDecode(response.body);
    return data.map((json) => SongModel.fromJson(json)).toList();
  } else {
    throw Exception('Failed to load songs');
  }
}


 */



Future<List<Song>> fetchSongs() async {
  // Replace with your actual API call
  final response = await http.get(Uri.parse("https://mocki.io/v1/df75d4d3-7803-4781-9d1a-f9eef8167d61"));
//  final response = await http.get(Uri.parse("https://mocki.io/v1/a3b49ac7-93a9-4ab5-926e-f635a3bb5d10"));
  if (response.statusCode == 200) {
    final data = jsonDecode(response.body) as List;
    return data.map((song) => Song.fromJson(song)).toList();
  } else {
    throw Exception("Failed to load songs");
  }
}
