
class Song {

  String name;
  String url;

  Song({
    required this.name,
    required this.url
});

  factory Song.fromJson(Map<String, dynamic> json)
  {
    return switch(json)
    {

      {
        'name' : String title,
        'url' : String url
    } => Song(name: title, url: url)
    , _ => throw const FormatException('Failed to load album.'),
    };
  }


}