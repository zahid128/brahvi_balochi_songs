import 'package:just_audio/just_audio.dart';
import '/Model/model_class.dart';
import 'package:flutter/material.dart';


class AudioProvider extends ChangeNotifier {

  final AudioPlayer _audioPlayer = AudioPlayer();
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = Duration.zero;
  bool _isPlaying = false;

  AudioProvider() {
    _audioPlayer.positionStream.listen((position) {
      _currentPosition = position;
      notifyListeners();
    });
    _audioPlayer.durationStream.listen((duration) {
      _totalDuration = duration ?? Duration.zero;
      notifyListeners();
    });
  }

  Duration get currentPosition => _currentPosition;
  Duration get totalDuration => _totalDuration;
  bool get isPlaying => _isPlaying;

  Future<void> play(String url) async {
    await _audioPlayer.setUrl(url);
    _audioPlayer.play();
    _isPlaying = true;
    notifyListeners();
  }

  void pause() {
    _audioPlayer.pause();
    _isPlaying = false;
    notifyListeners();
  }

  void seek(Duration position) {
    _audioPlayer.seek(position);
  }

  // AudioPlayer? _player;
  // Song? _currentSong;
  //
  // AudioProvider() {
  //   _player = AudioPlayer();
  // }
  //
  // Future<void> setSong(Song song) async {
  //   if (_currentSong == song) return;
  //   await _player?.stop();
  //   _currentSong = song;
  //   await _player?.setUrl(song.url);
  //   await _player?.play();
  //   notifyListeners();
  // }
  //
  // void play() async {
  //   await _player?.play();
  //   notifyListeners();
  // }
  //
  // void pause() async {
  //   await _player?.pause();
  //   notifyListeners();
  // }
  //
  // bool get isPlaying => _player?.playing ?? false;
  //
  // @override
  // void dispose() {
  //   _player?.dispose();
  //   super.dispose();
  // }
}
