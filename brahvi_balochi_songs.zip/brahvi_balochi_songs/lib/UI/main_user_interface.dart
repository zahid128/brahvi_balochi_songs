import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../Model/model_class.dart';
import 'package:brahvi_balochi_songs/API/API_class.dart';
import '../Player_State/player_state.dart';

class MyApp2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ChangeNotifierProvider(
        create: (context) => AudioProvider(),
        child: MainUserInterface(),
      ),
    );
  }
}
class MainUserInterface extends StatefulWidget {

  @override
  State<MainUserInterface> createState() => _MainUserInterfaceState();
}

class _MainUserInterfaceState extends State<MainUserInterface> {

  Future<List<Song>>? _songs;

  @override
  void initState() {
    super.initState();
    _songs = fetchSongs();
  }

  @override
  Widget build(BuildContext context) {
    final audioProvider = Provider.of<AudioProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text("Music Player"),
        centerTitle: true,
      ),
      body: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(20),
            child:
                FutureBuilder<List<Song>>(
                    future: _songs,
                    builder: (context,snapshot)
                  {
                  if(snapshot.hasData)
                    {
                      final songs = snapshot.data!;
                      return ListView.builder(
                          itemCount: songs.length,
                          itemBuilder: (context,index)
                      {
                        final song = songs[index];
                        return Card(
                          elevation: 1,
                          child: ListTile(
                            leading: CircleAvatar(
                            ),
                            title: Text(
                              song.name,),
                         //   onTap: () => audioProvider.(song),
                            subtitle: Text(song.url),
                          ),
                        );

                      });

                    }else if (snapshot.hasError) {
                    return Text("Error: ${snapshot.error}");
                  }
                  return CircularProgressIndicator();
                }
                ),
          ),
      ),





      // floatingActionButton: SafeArea(
      //   child: IconButton(
      //     icon: Icon(audioProvider.isPlaying ? Icons.pause : Icons.play_arrow),
      //     onPressed: () => audioProvider.isPlaying ? audioProvider.pause() : audioProvider.play(),
      //   ),
      // ),
    );
  }}
