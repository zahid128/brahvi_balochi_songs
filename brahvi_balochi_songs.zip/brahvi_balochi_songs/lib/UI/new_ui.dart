import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../API/API_class.dart';
import '../Model/model_class.dart';
import '../Player_State/player_state.dart';

class NewMyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ChangeNotifierProvider(
        create: (context) => AudioProvider(),
        child: NewUI(),
      ),
    );
  }
}

class NewUI extends StatefulWidget {
  const NewUI({super.key});

  @override
  State<NewUI> createState() => _NewUIState();
}
class _NewUIState extends State<NewUI> {

  Future<List<Song>>? _songs;

  String formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return [if (duration.inHours > 0) hours, minutes, seconds].join(':');
  }

  @override
  void initState() {
    super.initState();
    _songs = fetchSongs();
  }

  String currentName = "";
  String curentCover = "";
  String currentSinger = "";
  IconData iconBtn = Icons.play_arrow;
  String currentSong = "";

  @override
  Widget build(BuildContext context) {
    final audioProvider = Provider.of<AudioProvider>(context);
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text("Music Player"),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.transparent,
              Colors.black,
              Colors.black38,
            ],
          )
        ),
        child: Column(
          children: [
            Expanded(child:
            FutureBuilder<List<Song>>(
                future: _songs,
                builder: (context,snapshot)
                {
                  if(snapshot.hasData)
                  {
                    final songs = snapshot.data!;
                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.white12,
                      ),
                      child: ListView.builder(
                          itemCount: songs.length,
                          itemBuilder: (context,index)
                          {
                            final song = songs[index];
                            return Card(
                              color: Colors.white10,

                              elevation: 1,
                              child: ListTile(
                                leading: CircleAvatar(
                                ),
                                title: Text(
                                  song.name,
                                style: TextStyle(
                                  color: Colors.white
                                ),),
                                onTap: ()
                                {
                                    setState(() {
                                      currentName = song.name;
                                      currentSinger = song.url;
                                    });
                                    },

                                subtitle: Text(song.url,style: TextStyle(color: Colors.white),),
                                trailing: Icon(Icons.more_vert,
                                color: Colors.white,),
                              ),
                            );

                          }),
                    );

                  }else if (snapshot.hasError) {
                    return Text("Error: ${snapshot.error}");
                  }
                  return CircularProgressIndicator();
                }
                ),

            ),
            Container(
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
               color: Colors.white10,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  // BoxShadow(
                  //     color: Color(0x55212121),
                  //   blurRadius: 8.0
                  // )
                ]
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children:[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(formatDuration(audioProvider.currentPosition),style: TextStyle(color: Colors.white,),),
                      Slider(
                        value: audioProvider.currentPosition.inSeconds.toDouble(),
                        max: audioProvider.totalDuration.inSeconds.toDouble(),
                        onChanged: (value) {
                          audioProvider.seek(Duration(seconds: value.toInt()));
                        },
                      ),
                      Text(formatDuration(audioProvider.totalDuration),style: TextStyle( color: Colors.white,),),
                    ],
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: Icon(
                          audioProvider.isPlaying ? Icons.pause : Icons.play_arrow,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          if (audioProvider.isPlaying) {
                            audioProvider.pause();
                          } else {
                            audioProvider.play('https://pagalfree.com/musics/128-Hauli%20Hauli%20-%20Khel%20Khel%20Mein%20128%20Kbps.mp3');
                          }
                        },
                      ),
                    ],
                  ),

              ]),
            ),
          ],
        ),
      ),
    );
  }
}
