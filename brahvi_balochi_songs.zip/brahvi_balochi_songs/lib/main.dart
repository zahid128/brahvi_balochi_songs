import 'package:brahvi_balochi_songs/UI/main_user_interface.dart';
import 'package:brahvi_balochi_songs/UI/new_ui.dart';

import '/UI/Main_UI.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(
    MaterialApp(
      home: NewMyApp(),
    )
  );
}